import { Component, OnInit } from '@angular/core';
import { Show } from '../onlinemovie';
import { ShowServiceService } from '../show-service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-show',
  templateUrl: './add-show.component.html',
  styleUrls: ['./add-show.component.scss']
})
export class AddShowComponent implements OnInit {

  show:Show=new Show();
  info:string;
  errorinfo:string;
  constructor(private showService:ShowServiceService,private route: ActivatedRoute,private router: Router) { }

  ngOnInit(): void {
  }
  addShow(){
    this.show.seats.seatId=2;
    this.show.seats.seatPrice=100;
    this.showService.addShow(this.show).subscribe((data)=>{
      console.log(data);
      
      alert(data);
      this.router.navigate(['viewAllShow']);
    
    },
    error=>{
      this.info=undefined;
      this.errorinfo=error.error;
      console.log(this.errorinfo);
      alert(this.errorinfo.valueOf);
    });

  }

}
