import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

import { Theater } from './onlinemovie';

@Injectable({
  providedIn: 'root'
})
export class ManageTheaterService {
  baseUrl="http://localhost:8082/";
  constructor(private http:HttpClient) { }

  public addTheater(theater:Theater){
    
    return this.http.post("http://localhost:8082/addThater",theater,{responseType:'text'});
  }

  deleteTheater(theaterId:number){
    console.log(theaterId);
     return this.http.delete("http://localhost:8082/deleteTheater/"+theaterId,{responseType:'text'});

    //  console.log(movieId);
    //  return this.http.get(this.baseUrl+"viewAllMovie");
  }

  getTheater(theaterId:number):Observable<any>{
    return this.http.get(this.baseUrl+"viewTheater/"+theaterId);
  }
  viewTheaters():Observable<any>{
    return this.http.get(this.baseUrl+"viewAllTheater");
  }
}
