export class OnlineMovie {
}
export class Theater{
    theaterId:number;
    theaterName:string;
    theaterCity:string;
    managerName:string;
    managerContact:string;
}
export class Movie{
    movieId:number;
    movieName:string;
    genre:string;
    language:string;
    director:string;
}
export class Show{
    showId:number;
    showName:String;
    showstartTime:Date;
    showendTime:Date;
    totalNoOfSeats:number;
    noOfAvailableSeats:number;
    seats:Seat=new Seat();
    movieRef:Movie=new Movie();
    theater:Theater=new Theater();
}
export class Screen{
    screeinId:number;
    screenname:string;
    showlist:Show[]=[];
    screenrows:number;
    columns:number;
    theaterId:Theater=new Theater();
}
export class Booking{
    bookingId:number;
    showRef: Show=new Show();
    bookingDate:Date;
    transactionalId:number;
    totalCost:number;
    noOfSeats:number;
    bookingStatus:string;
}
export class Seat{
    seatId:number;
    seatStatus:string;
    seatPrice:number;
}
export class SeatsBooked{
    id:number;
    bookingId:number;
    seatNo:number;
}
export class Ticket{
    ticketId:number;
    noOfSeats:number;
    seatName:string;
    screenName:string;
    bookingRef:Booking=new Booking();
}
export class User{
    userId:number;
    userName:string;
    isAdmin:boolean;
    password:string;
}
