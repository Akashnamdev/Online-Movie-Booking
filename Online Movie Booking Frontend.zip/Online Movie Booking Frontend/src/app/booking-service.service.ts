import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Booking } from './onlinemovie';

@Injectable({
  providedIn: 'root'
})
export class BookingServiceService {
  baseUrl="http://localhost:8082/";
  constructor(private http:HttpClient) { }

  public addBooking(booking:Booking){
    
    return this.http.post("http://localhost:8082/addBooking",booking,{responseType:'text'});
  }

  cancleBooking(bookingId:number){
    
     return this.http.delete("http://localhost:8082/CancleBooking/"+bookingId,{responseType:'text'});
  }

  getBooking(bookingId:number):Observable<any>{
    return this.http.get(this.baseUrl+"getBooking/"+bookingId);
  }
  getBookings():Observable<any>{
    return this.http.get(this.baseUrl+"getBookings");
  }
}
