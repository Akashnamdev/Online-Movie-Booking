import { Component, OnInit } from '@angular/core';
import { Show, Booking } from '../onlinemovie';
import { ActivatedRoute, Router } from '@angular/router';
import { ShowServiceService } from '../show-service.service';
import { BookingServiceService } from '../booking-service.service';

@Component({
  selector: 'app-view-show',
  templateUrl: './view-show.component.html',
  styleUrls: ['./view-show.component.scss']
})
export class ViewShowComponent implements OnInit {

  info : String;
  errorInfo : String;
  showId:number;
  show:Show;
  booking:Booking=new Booking();
  
  constructor(private route: ActivatedRoute,private router: Router,
    private showService:ShowServiceService, private bookingService:BookingServiceService) { }

  ngOnInit(): void {
    this.show=new Show();
      this.showId = this.route.snapshot.params['showId'];
      this.showDetails(this.showId);
  }

  showDetails(showId:number){
    this.showService.viewShow(showId).subscribe(data=>this.show=data);
  }

  bookTicket(show:Show){
    console.log(show.showName);
    console.log(this.booking.noOfSeats);
    this.booking.showRef=show;
    this.booking.totalCost=this.booking.noOfSeats*100;
    this.booking.bookingStatus="Booked";
    this.bookingService.addBooking(this.booking).subscribe(data=>{
      this.info=data;
      this.info=this.info+" Total amount is "+this.booking.totalCost+"Rs";
      alert(this.info);
      this.router.navigate(['/viewShow']);
    },
    error=>{
      this.info=undefined;
      this.errorInfo=error.error;
      console.log(this.errorInfo);
      alert(this.errorInfo);
    }
    
    );

   

  }

}
