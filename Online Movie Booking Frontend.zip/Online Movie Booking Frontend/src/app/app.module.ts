import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClient,HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';

import { ViewallShowComponent } from './viewall-show/viewall-show.component';
import { ViewShowComponent } from './view-show/view-show.component';
import { ViewallBookingComponent } from './viewall-booking/viewall-booking.component';
import { ViewBookingComponent } from './view-booking/view-booking.component';
import { AddShowComponent } from './add-show/add-show.component';
import { CancelBookingComponent } from './cancel-booking/cancel-booking.component';
import { DeleteShowComponent } from './delete-show/delete-show.component';


@NgModule({
  declarations: [
    AppComponent,
    
    ViewallShowComponent,
    ViewShowComponent,
    ViewallBookingComponent,
    ViewBookingComponent,
    AddShowComponent,
    CancelBookingComponent,
    DeleteShowComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
