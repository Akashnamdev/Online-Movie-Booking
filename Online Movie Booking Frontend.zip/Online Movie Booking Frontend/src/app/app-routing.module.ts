import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { ViewallShowComponent } from './viewall-show/viewall-show.component';
import { ViewShowComponent } from './view-show/view-show.component';
import { ViewallBookingComponent } from './viewall-booking/viewall-booking.component';
import { ViewBookingComponent } from './view-booking/view-booking.component';
import { AddShowComponent } from './add-show/add-show.component';
import { DeleteShowComponent } from './delete-show/delete-show.component';





const routes: Routes = [
  {path:"deleteShow", component:DeleteShowComponent},
 {path:"getBooking/:bookingId", component:ViewBookingComponent},
  {path:"getBookings", component:ViewallBookingComponent},
  {path:"viewAllShow", component:ViewallShowComponent},
  {path:"viewShow/:showId", component:ViewShowComponent},
  {path:"addShow", component:AddShowComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
