import { Component, OnInit } from '@angular/core';
import { Show } from '../onlinemovie';
import { ShowServiceService } from '../show-service.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-viewall-show',
  templateUrl: './viewall-show.component.html',
  styleUrls: ['./viewall-show.component.scss']
})
export class ViewallShowComponent implements OnInit {
  shows:Show[]=[];
  constructor(private showService:ShowServiceService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData() {
    //this.centers = this.centerService.loadCenters();
    this.showService.viewAllShow()
    .subscribe(data=>{
      this.shows=data;
      console.log(data);
    })
  }

  showDetails(showId:number){
    this.router.navigate(['viewShow',showId]);
  }

}
