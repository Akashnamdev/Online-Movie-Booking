import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewallShowComponent } from './viewall-show.component';

describe('ViewallShowComponent', () => {
  let component: ViewallShowComponent;
  let fixture: ComponentFixture<ViewallShowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewallShowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewallShowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
