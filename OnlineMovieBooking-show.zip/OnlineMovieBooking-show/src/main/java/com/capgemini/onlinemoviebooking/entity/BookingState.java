package com.capgemini.onlinemoviebooking.entity;

public enum BookingState {
	Available,
	Blocked,
	Booked,
	Cancelled

}
