package com.capgemini.onlinemoviebooking.exception;

public class MovieException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MovieException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MovieException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MovieException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MovieException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MovieException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
